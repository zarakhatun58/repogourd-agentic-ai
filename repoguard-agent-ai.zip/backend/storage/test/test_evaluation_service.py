from app.services.evaluation_service import (
    BENCHMARK_CASES,
    _detected_rules,
    _f1,
    _score,
)


def test_benchmark_has_ten_cases():
    assert len(BENCHMARK_CASES) == 10


def test_clean_case_has_no_findings():
    case = BENCHMARK_CASES[0]
    _, _, _, filename, source, expected = case
    assert expected == []
    assert _detected_rules(source, False, filename) == []
    assert _detected_rules(source, True, filename) == []


def test_advanced_detector_catches_expected_rules():
    for _, _, _, filename, source, expected in BENCHMARK_CASES:
        detected = set(_detected_rules(source, True, filename))
        assert set(expected).issubset(detected)


def test_advanced_scores_higher_than_baseline_on_most_cases():
    improvements = 0
    for _, _, _, filename, source, expected in BENCHMARK_CASES:
        if _score(expected, _detected_rules(source, True, filename)) > _score(
            expected, _detected_rules(source, False, filename)
        ):
            improvements += 1
    assert improvements >= 5


def test_f1_is_zero_when_every_expected_issue_is_missed():
    assert _f1(0, 0, 2) == 0
